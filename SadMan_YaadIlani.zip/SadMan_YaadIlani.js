(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"SadMan_YaadIlani_atlas_", frames: [[222,0,613,153],[837,0,592,153],[1431,0,576,153],[907,155,556,153],[801,1740,526,153],[761,1895,495,153],[1258,1895,466,153],[1203,979,439,153],[1286,1292,407,153],[1644,979,399,153],[1142,1134,418,156],[0,438,229,408],[0,848,230,396],[1024,535,177,447],[0,1246,208,427],[866,1340,208,398],[1288,310,172,475],[231,399,221,391],[232,792,221,391],[455,792,221,391],[677,155,228,376],[1636,380,228,350],[866,1035,274,303],[677,535,328,254],[678,791,344,242],[222,155,366,242],[0,1675,378,234],[907,310,379,223],[380,1803,379,223],[420,1578,379,223],[1465,155,379,223],[1554,1447,379,158],[1329,1680,379,158],[1286,1447,266,231],[454,399,221,391],[420,1185,221,391],[1866,155,177,447],[210,1246,208,427],[1076,1340,208,398],[1462,380,172,475],[643,1185,221,391],[0,0,220,436],[1203,857,606,120]]},
		{name:"SadMan_YaadIlani_atlas_2", frames: [[381,0,368,153],[1088,387,86,90],[254,160,124,64],[337,703,1278,6],[87,539,1299,22],[773,142,129,307],[254,266,216,166],[273,563,62,164],[472,266,143,218],[87,160,165,218],[1396,421,115,234],[904,142,171,227],[1742,0,190,228],[1536,0,101,430],[1934,0,85,444],[261,434,43,53],[0,0,379,158],[381,155,390,109],[751,0,361,140],[1243,0,185,252],[1742,230,136,252],[1513,432,96,269],[216,434,43,54],[1639,0,101,430],[0,160,85,444],[1176,387,43,56],[1880,230,43,297],[1851,529,60,174],[1789,484,60,174],[1727,484,60,174],[87,563,60,174],[149,563,60,174],[1925,446,60,174],[1114,0,127,385],[1430,0,104,419],[617,266,134,208],[904,371,182,166],[1611,432,114,153],[211,563,60,174],[1243,254,151,214],[87,380,127,143]]}
];


// symbols:



(lib.CachedTexturedBitmap_1242 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1244 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1245 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1246 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1247 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1248 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1249 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1250 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1251 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1252 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1253 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1254 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1292 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1308 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1309 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1310 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1311 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1372 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1373 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1375 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1376 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1377 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1378 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1379 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1380 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1381 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1531 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1532 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1533 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1534 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1535 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1536 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1537 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1538 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1539 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1540 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1541 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1542 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1543 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1544 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1545 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1546 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1547 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1548 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1549 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1550 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1551 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1552 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1553 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1554 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1555 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1556 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1557 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1558 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1559 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1560 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1561 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1622 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1623 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1624 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1625 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1626 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1627 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1628 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1629 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1630 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1631 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1632 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1638 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1646 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1654 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1662 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1670 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1678 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1681 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1682 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1683 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1684 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1685 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1686 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1687 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1688 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_2"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1689 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1690 = function() {
	this.initialize(ss["SadMan_YaadIlani_atlas_"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol_1_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_1690();
	this.instance.parent = this;
	this.instance.setTransform(-1.5,-1.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol_1_Layer_1, null, null);


(lib.Scene_1_Tear_Drops = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Tear_Drops
	this.instance = new lib.CachedTexturedBitmap_1311();
	this.instance.parent = this;
	this.instance.setTransform(112.35,243.5,0.5,0.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(280).to({_off:false},0).to({_off:true},25).wait(19));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_Car_And_Puddle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Car_And_Puddle
	this.instance = new lib.CachedTexturedBitmap_1242();
	this.instance.parent = this;
	this.instance.setTransform(646.1,226.1,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_1244();
	this.instance_1.parent = this;
	this.instance_1.setTransform(241.1,226.1,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_1245();
	this.instance_2.parent = this;
	this.instance_2.setTransform(230.3,226.1,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_1246();
	this.instance_3.parent = this;
	this.instance_3.setTransform(218.15,226.1,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_1247();
	this.instance_4.parent = this;
	this.instance_4.setTransform(206.45,226.1,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_1248();
	this.instance_5.parent = this;
	this.instance_5.setTransform(193.4,226.1,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_1249();
	this.instance_6.parent = this;
	this.instance_6.setTransform(177.2,226.1,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_1250();
	this.instance_7.parent = this;
	this.instance_7.setTransform(162.8,226.1,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_1251();
	this.instance_8.parent = this;
	this.instance_8.setTransform(162.8,226.1,0.5,0.5);

	this.instance_9 = new lib.CachedTexturedBitmap_1252();
	this.instance_9.parent = this;
	this.instance_9.setTransform(153.7,226.1,0.5,0.5);

	this.instance_10 = new lib.CachedTexturedBitmap_1253();
	this.instance_10.parent = this;
	this.instance_10.setTransform(138.35,226.1,0.5,0.5);

	this.instance_11 = new lib.CachedTexturedBitmap_1254();
	this.instance_11.parent = this;
	this.instance_11.setTransform(128.65,226.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance}]},234).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},5).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(234).to({x:625.4},0).wait(1).to({x:613.7},0).wait(1).to({x:601.1},0).wait(1).to({x:588.5},0).wait(1).to({x:573.2},0).wait(1).to({x:557.9},0).wait(1).to({x:545.3},0).wait(1).to({x:531.8},0).wait(1).to({x:518.3},0).wait(1).to({x:500.3},0).wait(1).to({x:484.1},0).wait(1).to({x:470.6},0).wait(1).to({x:457.1},0).wait(1).to({x:438.2},0).wait(1).to({x:427.4},0).wait(1).to({x:413},0).wait(1).to({x:395},0).wait(1).to({x:374.3},0).wait(1).to({x:359},0).wait(1).to({x:348.2},0).wait(1).to({x:334.7},0).wait(1).to({x:316.7},0).wait(1).to({x:305.9},0).wait(1).to({x:295.1},0).wait(1).to({x:279.8},0).wait(1).to({x:263.6},0).wait(1).to({x:251.9},0).to({_off:true},1).wait(20));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_Bent_Man = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Bent_Man
	this.instance = new lib.CachedTexturedBitmap_1372();
	this.instance.parent = this;
	this.instance.setTransform(69.3,269.35,0.5,0.5);
	this.instance._off = true;

	this.instance_1 = new lib.CachedTexturedBitmap_1373();
	this.instance_1.parent = this;
	this.instance_1.setTransform(93.45,256.05,0.5,0.5);
	this.instance_1._off = true;

	this.instance_2 = new lib.CachedTexturedBitmap_1375();
	this.instance_2.parent = this;
	this.instance_2.setTransform(108.6,215.55,0.5,0.5);
	this.instance_2._off = true;

	this.instance_3 = new lib.CachedTexturedBitmap_1376();
	this.instance_3.parent = this;
	this.instance_3.setTransform(90.8,235.65,0.5,0.5);
	this.instance_3._off = true;

	this.instance_4 = new lib.CachedTexturedBitmap_1377();
	this.instance_4.parent = this;
	this.instance_4.setTransform(108.35,228.25,0.5,0.5);
	this.instance_4._off = true;

	this.instance_5 = new lib.CachedTexturedBitmap_1378();
	this.instance_5.parent = this;
	this.instance_5.setTransform(110.75,211.35,0.5,0.5);
	this.instance_5._off = true;

	this.instance_6 = new lib.CachedTexturedBitmap_1379();
	this.instance_6.parent = this;
	this.instance_6.setTransform(71.1,215.2,0.5,0.5);
	this.instance_6._off = true;

	this.instance_7 = new lib.CachedTexturedBitmap_1380();
	this.instance_7.parent = this;
	this.instance_7.setTransform(87.8,239.05,0.5,0.5);
	this.instance_7._off = true;

	this.instance_8 = new lib.CachedTexturedBitmap_1381();
	this.instance_8.parent = this;
	this.instance_8.setTransform(68.6,222.7,0.5,0.5);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(305).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(306).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(8));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(307).to({_off:false},0).wait(1).to({x:100.65,y:230.1},0).to({_off:true},1).wait(8).to({_off:false,x:108.6,y:215.55},0).wait(1).to({x:100.65,y:230.1},0).to({_off:true},1).wait(8).to({_off:false,x:108.6,y:215.55},0).wait(1).to({x:100.65,y:230.1},0).to({_off:true},1).wait(8).to({_off:false,x:108.6,y:215.55},0).wait(1).to({x:100.65,y:230.1},0).to({_off:true},1).wait(8).to({_off:false,x:108.6,y:215.55},0).wait(1).to({x:100.65,y:230.1},0).to({_off:true},1).wait(8).to({_off:false,x:108.6,y:215.55},0).wait(1).to({x:100.65,y:230.1},0).to({_off:true},1).wait(8).to({_off:false,x:108.6,y:215.55},0).wait(1).to({x:100.65,y:230.1},0).to({_off:true},1).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(309).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(310).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(4));
	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(311).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(3));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(312).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(2));
	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(313).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(314).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_Banana_Skin = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Banana_Skin
	this.instance = new lib.CachedTexturedBitmap_1308();
	this.instance.parent = this;
	this.instance.setTransform(642.45,390.8,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_1292();
	this.instance_1.parent = this;
	this.instance_1.setTransform(140.85,378,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance}]},121).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[]},7).wait(16));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(121).to({x:621.45},0).wait(1).to({x:613.95},0).wait(1).to({x:601.2},0).wait(1).to({x:591.45},0).wait(1).to({x:580.2},0).wait(1).to({x:568.95},0).wait(1).to({x:554.7},0).wait(1).to({x:534.45},0).wait(1).to({x:515.7},0).wait(1).to({x:500.7},0).wait(1).to({x:486.45},0).wait(1).to({x:472.2},0).wait(1).to({x:454.2},0).wait(1).to({x:437.7},0).wait(1).to({x:422.7},0).wait(1).to({x:403.2},0).wait(1).to({x:386.7},0).wait(1).to({x:370.95},0).wait(1).to({x:349.95},0).wait(1).to({x:333.45},0).wait(1).to({x:316.95},0).wait(1).to({x:301.2},0).wait(1).to({x:286.2},0).wait(1).to({x:271.95},0).wait(1).to({x:256.95},0).wait(1).to({x:243.45},0).wait(1).to({x:228.45},0).wait(2).to({x:220.95},0).wait(1).to({x:209.7},0).wait(1).to({x:198.45},0).wait(1).to({x:184.95},0).wait(1).to({x:171.45},0).wait(1).to({x:157.95},0).wait(1).to({x:145.95},0).wait(1).to({x:135.45},0).to({_off:true},1).wait(1).to({_off:false,x:109.2},0).wait(2).to({x:96.45},0).wait(1).to({x:85.2},0).wait(1).to({x:70.2},0).wait(2).to({x:58.2},0).wait(1).to({x:44.7},0).wait(1).to({x:34.2},0).wait(1).to({x:20.7},0).wait(1).to({x:7.95},0).wait(1).to({x:-9.3},0).wait(1).to({x:-19.05},0).wait(1).to({x:-34.8},0).wait(1).to({x:-62.55},0).wait(1).to({_off:true},7).wait(16));

}).prototype = p = new cjs.MovieClip();


(lib.Human_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_1689();
	this.instance.parent = this;
	this.instance.setTransform(-47,-96,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Human_Layer_1, null, null);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.Symbol_1_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(150,28.5,1,1,0,0,0,150,28.5);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(-1.5,-1.5,303,60), null);


(lib.Human = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.Human_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(8,13,1,1,0,0,0,8,13);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Human, new cjs.Rectangle(-47,-96,110,218), null);


(lib.Clouds_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol1();
	this.instance.parent = this;
	this.instance.setTransform(827.25,-92.9,1,1,0,0,0,362.9,69);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:150,regY:28.5,x:574.8,y:-133.4},0).wait(1).to({x:535.2},0).wait(1).to({x:495.6},0).wait(1).to({x:456.05},0).wait(1).to({x:416.4},0).wait(1).to({x:376.85},0).wait(1).to({x:337.3},0).wait(1).to({x:297.7},0).wait(1).to({x:258.1},0).wait(1).to({x:218.5},0).wait(1).to({x:178.95},0).wait(1).to({x:139.45},0).wait(1).to({x:99.8},0).wait(1).to({x:60.25},0).wait(1).to({x:20.65},0).wait(1).to({x:-18.9},0).wait(1).to({x:-58.5},0).wait(1).to({x:-98.1},0).wait(1).to({x:-137.7},0).wait(1).to({x:-177.25},0).wait(1).to({x:-216.8},0).wait(1).to({x:-256.4},0).wait(1).to({x:-296},0).wait(1).to({x:-335.55},0).wait(1).to({x:-375.15},0).wait(1).to({x:-414.75},0).wait(1).to({x:-454.3},0).wait(1).to({x:-493.85},0).wait(1).to({x:-533.5},0).wait(1).to({x:-573.05},0).wait(1).to({x:-612.65},0).wait(1).to({x:-652.2},0).wait(1).to({x:-691.8},0).wait(1).to({x:-731.4},0).wait(1).to({x:-771},0).wait(1).to({x:-810.55},0).wait(1).to({x:-850.15},0).wait(1).to({x:-889.75},0).wait(1).to({x:-929.25},0).wait(1).to({x:-968.9},0).wait(1).to({x:-1008.45},0).wait(1).to({x:-1048},0).wait(1).to({x:-1087.65},0).wait(1).to({x:-1127.2},0).wait(1).to({x:-1166.8},0).wait(1).to({x:-1206.4},0).wait(1).to({x:-1245.9},0).wait(1).to({x:-1285.5},0).wait(1).to({x:-1325.15},0).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Clouds = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_49 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(49).call(this.frame_49).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.Clouds_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(645,-128.2,1,1,0,0,0,645,-128.2);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1).to({regX:-355.4,regY:-133.4,x:-355.4,y:-133.4},0).wait(49));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1476.6,-163.4,2242.5,60);


(lib.Scene_1_Setting = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Setting
	this.instance = new lib.Clouds();
	this.instance.parent = this;
	this.instance.setTransform(38.7,106.75,1,1,0,0,0,39.6,-93);

	this.instance_1 = new lib.CachedTexturedBitmap_1309();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.4,420.85,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_1310();
	this.instance_2.parent = this;
	this.instance_2.setTransform(0.4,413.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance}]},244).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_Human = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Human
	this.instance = new lib.Human();
	this.instance.parent = this;
	this.instance.setTransform(173.05,409.4,1,1,0,0,0,54.9,109);

	this.instance_1 = new lib.CachedTexturedBitmap_1537();
	this.instance_1.parent = this;
	this.instance_1.setTransform(110.2,210.3,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_1538();
	this.instance_2.parent = this;
	this.instance_2.setTransform(73.05,225.95,0.5,0.5);
	this.instance_2._off = true;

	this.instance_3 = new lib.CachedTexturedBitmap_1531();
	this.instance_3.parent = this;
	this.instance_3.setTransform(91.4,207.95,0.5,0.5);
	this.instance_3._off = true;

	this.instance_4 = new lib.CachedTexturedBitmap_1532();
	this.instance_4.parent = this;
	this.instance_4.setTransform(91.2,200,0.5,0.5);
	this.instance_4._off = true;

	this.instance_5 = new lib.CachedTexturedBitmap_1533();
	this.instance_5.parent = this;
	this.instance_5.setTransform(78.75,205.55,0.5,0.5);
	this.instance_5._off = true;

	this.instance_6 = new lib.CachedTexturedBitmap_1534();
	this.instance_6.parent = this;
	this.instance_6.setTransform(80.1,220.2,0.5,0.5);
	this.instance_6._off = true;

	this.instance_7 = new lib.CachedTexturedBitmap_1535();
	this.instance_7.parent = this;
	this.instance_7.setTransform(104.05,198.85,0.5,0.5);
	this.instance_7._off = true;

	this.instance_8 = new lib.CachedTexturedBitmap_1536();
	this.instance_8.parent = this;
	this.instance_8.setTransform(90.8,187.4,0.5,0.5);
	this.instance_8._off = true;

	this.instance_9 = new lib.CachedTexturedBitmap_1539();
	this.instance_9.parent = this;
	this.instance_9.setTransform(73.05,225.95,0.5,0.5);

	this.instance_10 = new lib.CachedTexturedBitmap_1540();
	this.instance_10.parent = this;
	this.instance_10.setTransform(73.05,225.95,0.5,0.5);

	this.instance_11 = new lib.CachedTexturedBitmap_1541();
	this.instance_11.parent = this;
	this.instance_11.setTransform(60.1,233.15,0.5,0.5);

	this.instance_12 = new lib.CachedTexturedBitmap_1542();
	this.instance_12.parent = this;
	this.instance_12.setTransform(60.1,233.15,0.5,0.5);

	this.instance_13 = new lib.CachedTexturedBitmap_1543();
	this.instance_13.parent = this;
	this.instance_13.setTransform(42.35,247.3,0.5,0.5);

	this.instance_14 = new lib.CachedTexturedBitmap_1544();
	this.instance_14.parent = this;
	this.instance_14.setTransform(27.9,255.95,0.5,0.5);

	this.instance_15 = new lib.CachedTexturedBitmap_1545();
	this.instance_15.parent = this;
	this.instance_15.setTransform(23.8,264.7,0.5,0.5);

	this.instance_16 = new lib.CachedTexturedBitmap_1546();
	this.instance_16.parent = this;
	this.instance_16.setTransform(19.2,270.85,0.5,0.5);

	this.instance_17 = new lib.CachedTexturedBitmap_1547();
	this.instance_17.parent = this;
	this.instance_17.setTransform(17.15,279.35,0.5,0.5);

	this.instance_18 = new lib.CachedTexturedBitmap_1548();
	this.instance_18.parent = this;
	this.instance_18.setTransform(17.05,291.15,0.5,0.5);

	this.instance_19 = new lib.CachedTexturedBitmap_1549();
	this.instance_19.parent = this;
	this.instance_19.setTransform(17.05,299.15,0.5,0.5);

	this.instance_20 = new lib.CachedTexturedBitmap_1550();
	this.instance_20.parent = this;
	this.instance_20.setTransform(17.05,304.75,0.5,0.5);

	this.instance_21 = new lib.CachedTexturedBitmap_1551();
	this.instance_21.parent = this;
	this.instance_21.setTransform(17.05,311.55,0.5,0.5);

	this.instance_22 = new lib.CachedTexturedBitmap_1552();
	this.instance_22.parent = this;
	this.instance_22.setTransform(17.05,322.75,0.5,0.5);

	this.instance_23 = new lib.CachedTexturedBitmap_1553();
	this.instance_23.parent = this;
	this.instance_23.setTransform(17.05,328.15,0.5,0.5);

	this.instance_24 = new lib.CachedTexturedBitmap_1554();
	this.instance_24.parent = this;
	this.instance_24.setTransform(17.05,343.95,0.5,0.5);

	this.instance_25 = new lib.CachedTexturedBitmap_1555();
	this.instance_25.parent = this;
	this.instance_25.setTransform(17.05,368.5,0.5,0.5);

	this.instance_26 = new lib.CachedTexturedBitmap_1556();
	this.instance_26.parent = this;
	this.instance_26.setTransform(31.7,353.1,0.5,0.5);

	this.instance_27 = new lib.CachedTexturedBitmap_1557();
	this.instance_27.parent = this;
	this.instance_27.setTransform(78.9,307.15,0.5,0.5);

	this.instance_28 = new lib.CachedTexturedBitmap_1558();
	this.instance_28.parent = this;
	this.instance_28.setTransform(119.6,296.9,0.5,0.5);

	this.instance_29 = new lib.CachedTexturedBitmap_1559();
	this.instance_29.parent = this;
	this.instance_29.setTransform(119.6,296.9,0.5,0.5);

	this.instance_30 = new lib.CachedTexturedBitmap_1560();
	this.instance_30.parent = this;
	this.instance_30.setTransform(123.7,286.3,0.5,0.5);

	this.instance_31 = new lib.CachedTexturedBitmap_1561();
	this.instance_31.parent = this;
	this.instance_31.setTransform(104.45,227,0.5,0.5);

	this.instance_32 = new lib.CachedTexturedBitmap_1622();
	this.instance_32.parent = this;
	this.instance_32.setTransform(110.2,210.3,0.5,0.5);

	this.instance_33 = new lib.CachedTexturedBitmap_1623();
	this.instance_33.parent = this;
	this.instance_33.setTransform(73.05,225.95,0.5,0.5);
	this.instance_33._off = true;

	this.instance_34 = new lib.CachedTexturedBitmap_1624();
	this.instance_34.parent = this;
	this.instance_34.setTransform(91.4,207.95,0.5,0.5);
	this.instance_34._off = true;

	this.instance_35 = new lib.CachedTexturedBitmap_1625();
	this.instance_35.parent = this;
	this.instance_35.setTransform(91.2,200,0.5,0.5);
	this.instance_35._off = true;

	this.instance_36 = new lib.CachedTexturedBitmap_1626();
	this.instance_36.parent = this;
	this.instance_36.setTransform(78.75,205.55,0.5,0.5);
	this.instance_36._off = true;

	this.instance_37 = new lib.CachedTexturedBitmap_1627();
	this.instance_37.parent = this;
	this.instance_37.setTransform(80.1,220.2,0.5,0.5);
	this.instance_37._off = true;

	this.instance_38 = new lib.CachedTexturedBitmap_1628();
	this.instance_38.parent = this;
	this.instance_38.setTransform(104.05,198.85,0.5,0.5);
	this.instance_38._off = true;

	this.instance_39 = new lib.CachedTexturedBitmap_1629();
	this.instance_39.parent = this;
	this.instance_39.setTransform(90.8,187.4,0.5,0.5);
	this.instance_39._off = true;

	this.instance_40 = new lib.CachedTexturedBitmap_1630();
	this.instance_40.parent = this;
	this.instance_40.setTransform(110.2,210.3,0.5,0.5);

	this.instance_41 = new lib.CachedTexturedBitmap_1631();
	this.instance_41.parent = this;
	this.instance_41.setTransform(73.05,225.95,0.5,0.5);
	this.instance_41._off = true;

	this.instance_42 = new lib.CachedTexturedBitmap_1632();
	this.instance_42.parent = this;
	this.instance_42.setTransform(110.2,210.3,0.5,0.5);

	this.instance_43 = new lib.CachedTexturedBitmap_1681();
	this.instance_43.parent = this;
	this.instance_43.setTransform(78.3,228.8,0.5,0.5);
	this.instance_43._off = true;

	this.instance_44 = new lib.CachedTexturedBitmap_1682();
	this.instance_44.parent = this;
	this.instance_44.setTransform(91.4,213.25,0.5,0.5);
	this.instance_44._off = true;

	this.instance_45 = new lib.CachedTexturedBitmap_1683();
	this.instance_45.parent = this;
	this.instance_45.setTransform(91.2,319.85,0.5,0.5);
	this.instance_45._off = true;

	this.instance_46 = new lib.CachedTexturedBitmap_1684();
	this.instance_46.parent = this;
	this.instance_46.setTransform(78.75,336,0.5,0.5);
	this.instance_46._off = true;

	this.instance_47 = new lib.CachedTexturedBitmap_1685();
	this.instance_47.parent = this;
	this.instance_47.setTransform(87.4,342.6,0.5,0.5);
	this.instance_47._off = true;

	this.instance_48 = new lib.CachedTexturedBitmap_1638();
	this.instance_48.parent = this;
	this.instance_48.setTransform(104.05,334.1,0.5,0.5);

	this.instance_49 = new lib.CachedTexturedBitmap_1687();
	this.instance_49.parent = this;
	this.instance_49.setTransform(90.8,318.15,0.5,0.5);
	this.instance_49._off = true;

	this.instance_50 = new lib.CachedTexturedBitmap_1688();
	this.instance_50.parent = this;
	this.instance_50.setTransform(78.3,349.65,0.5,0.5);
	this.instance_50._off = true;

	this.instance_51 = new lib.CachedTexturedBitmap_1646();
	this.instance_51.parent = this;
	this.instance_51.setTransform(104.05,334.1,0.5,0.5);

	this.instance_52 = new lib.CachedTexturedBitmap_1654();
	this.instance_52.parent = this;
	this.instance_52.setTransform(104.05,334.1,0.5,0.5);

	this.instance_53 = new lib.CachedTexturedBitmap_1662();
	this.instance_53.parent = this;
	this.instance_53.setTransform(104.05,334.1,0.5,0.5);

	this.instance_54 = new lib.CachedTexturedBitmap_1670();
	this.instance_54.parent = this;
	this.instance_54.setTransform(104.05,334.1,0.5,0.5);

	this.instance_55 = new lib.CachedTexturedBitmap_1678();
	this.instance_55.parent = this;
	this.instance_55.setTransform(104.05,334.1,0.5,0.5);

	this.instance_56 = new lib.CachedTexturedBitmap_1686();
	this.instance_56.parent = this;
	this.instance_56.setTransform(104.05,334.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_1},{t:this.instance}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_1},{t:this.instance}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_1},{t:this.instance}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_1},{t:this.instance}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_1},{t:this.instance}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_1},{t:this.instance}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_1},{t:this.instance}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_1},{t:this.instance}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_1},{t:this.instance}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_1},{t:this.instance}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_1},{t:this.instance}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_1},{t:this.instance}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_1},{t:this.instance}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_1},{t:this.instance}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_1},{t:this.instance}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_1},{t:this.instance}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_1},{t:this.instance}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_1},{t:this.instance}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_1},{t:this.instance}]},1).to({state:[{t:this.instance_1},{t:this.instance}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_1},{t:this.instance}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_24}]},1).to({state:[{t:this.instance_25}]},1).to({state:[{t:this.instance_26}]},18).to({state:[{t:this.instance_27}]},2).to({state:[{t:this.instance_28}]},2).to({state:[{t:this.instance_29}]},3).to({state:[{t:this.instance_30}]},2).to({state:[{t:this.instance_31}]},2).to({state:[{t:this.instance_32},{t:this.instance}]},1).to({state:[{t:this.instance_33}]},1).to({state:[{t:this.instance_34}]},1).to({state:[{t:this.instance_35}]},1).to({state:[{t:this.instance_36}]},1).to({state:[{t:this.instance_37}]},1).to({state:[{t:this.instance_38}]},1).to({state:[{t:this.instance_39}]},1).to({state:[{t:this.instance_40},{t:this.instance}]},1).to({state:[{t:this.instance_41}]},1).to({state:[{t:this.instance_32},{t:this.instance}]},1).to({state:[{t:this.instance_33}]},1).to({state:[{t:this.instance_34}]},1).to({state:[{t:this.instance_35}]},1).to({state:[{t:this.instance_36}]},1).to({state:[{t:this.instance_37}]},1).to({state:[{t:this.instance_38}]},1).to({state:[{t:this.instance_39}]},1).to({state:[{t:this.instance_40},{t:this.instance}]},1).to({state:[{t:this.instance_41}]},1).to({state:[{t:this.instance_32},{t:this.instance}]},1).to({state:[{t:this.instance_33}]},1).to({state:[{t:this.instance_34}]},1).to({state:[{t:this.instance_35}]},1).to({state:[{t:this.instance_36}]},1).to({state:[{t:this.instance_37}]},1).to({state:[{t:this.instance_38}]},1).to({state:[{t:this.instance_39}]},1).to({state:[{t:this.instance_40},{t:this.instance}]},1).to({state:[{t:this.instance_41}]},1).to({state:[{t:this.instance_32},{t:this.instance}]},1).to({state:[{t:this.instance_33}]},1).to({state:[{t:this.instance_34}]},1).to({state:[{t:this.instance_35}]},1).to({state:[{t:this.instance_36}]},1).to({state:[{t:this.instance_37}]},1).to({state:[{t:this.instance_38}]},1).to({state:[{t:this.instance_39}]},1).to({state:[{t:this.instance_40},{t:this.instance}]},1).to({state:[{t:this.instance_41}]},1).to({state:[{t:this.instance_32},{t:this.instance}]},1).to({state:[{t:this.instance_33}]},1).to({state:[{t:this.instance_34}]},1).to({state:[{t:this.instance_35}]},1).to({state:[{t:this.instance_36}]},1).to({state:[{t:this.instance_37}]},1).to({state:[{t:this.instance_38}]},1).to({state:[{t:this.instance_39}]},1).to({state:[{t:this.instance_40},{t:this.instance}]},1).to({state:[{t:this.instance_41}]},1).to({state:[{t:this.instance_32},{t:this.instance}]},1).to({state:[{t:this.instance_33}]},1).to({state:[{t:this.instance_34}]},1).to({state:[{t:this.instance_35}]},1).to({state:[{t:this.instance_36}]},1).to({state:[{t:this.instance_37}]},1).to({state:[{t:this.instance_38}]},1).to({state:[{t:this.instance_39}]},1).to({state:[{t:this.instance_40},{t:this.instance}]},1).to({state:[{t:this.instance_41}]},1).to({state:[{t:this.instance_32},{t:this.instance}]},1).to({state:[{t:this.instance_33}]},1).to({state:[{t:this.instance_34}]},1).to({state:[{t:this.instance_35}]},1).to({state:[{t:this.instance_36}]},1).to({state:[{t:this.instance_37}]},1).to({state:[{t:this.instance_38}]},1).to({state:[{t:this.instance_39}]},1).to({state:[{t:this.instance_40},{t:this.instance}]},1).to({state:[{t:this.instance_41}]},1).to({state:[{t:this.instance_42},{t:this.instance}]},8).to({state:[{t:this.instance_43}]},25).to({state:[{t:this.instance_44}]},1).to({state:[{t:this.instance_45}]},1).to({state:[{t:this.instance_46}]},1).to({state:[{t:this.instance_47}]},1).to({state:[{t:this.instance_48}]},1).to({state:[{t:this.instance_49}]},1).to({state:[]},1).to({state:[{t:this.instance_50}]},1).to({state:[]},1).to({state:[{t:this.instance_43}]},1).to({state:[{t:this.instance_44}]},1).to({state:[{t:this.instance_45}]},1).to({state:[{t:this.instance_46}]},1).to({state:[{t:this.instance_47}]},1).to({state:[{t:this.instance_51}]},1).to({state:[{t:this.instance_49}]},1).to({state:[]},1).to({state:[{t:this.instance_50}]},1).to({state:[]},1).to({state:[{t:this.instance_43}]},1).to({state:[{t:this.instance_44}]},1).to({state:[{t:this.instance_45}]},1).to({state:[{t:this.instance_46}]},1).to({state:[{t:this.instance_47}]},1).to({state:[{t:this.instance_52}]},1).to({state:[{t:this.instance_49}]},1).to({state:[]},1).to({state:[{t:this.instance_50}]},1).to({state:[]},1).to({state:[{t:this.instance_43}]},1).to({state:[{t:this.instance_44}]},1).to({state:[{t:this.instance_45}]},1).to({state:[{t:this.instance_46}]},1).to({state:[{t:this.instance_47}]},1).to({state:[{t:this.instance_53}]},1).to({state:[{t:this.instance_49}]},1).to({state:[]},1).to({state:[{t:this.instance_50}]},1).to({state:[]},1).to({state:[{t:this.instance_43}]},1).to({state:[{t:this.instance_44}]},1).to({state:[{t:this.instance_45}]},1).to({state:[{t:this.instance_46}]},1).to({state:[{t:this.instance_47}]},1).to({state:[{t:this.instance_54}]},1).to({state:[{t:this.instance_49}]},1).to({state:[]},1).to({state:[{t:this.instance_50}]},1).to({state:[]},1).to({state:[{t:this.instance_43}]},1).to({state:[{t:this.instance_44}]},1).to({state:[{t:this.instance_45}]},1).to({state:[{t:this.instance_46}]},1).to({state:[{t:this.instance_47}]},1).to({state:[{t:this.instance_55}]},1).to({state:[{t:this.instance_49}]},1).to({state:[]},1).to({state:[{t:this.instance_50}]},1).to({state:[]},1).to({state:[{t:this.instance_43}]},1).to({state:[{t:this.instance_44}]},1).to({state:[{t:this.instance_45}]},1).to({state:[{t:this.instance_46}]},1).to({state:[{t:this.instance_47}]},1).to({state:[{t:this.instance_56}]},1).to({state:[{t:this.instance_49}]},1).to({state:[]},1).to({state:[{t:this.instance_50}]},1).to({state:[]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(218));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(2).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(225));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(3).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(224));
	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(4).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(223));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(5).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(222));
	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(221));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(7).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(7).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(220));
	this.timeline.addTween(cjs.Tween.get(this.instance_33).wait(204).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(110));
	this.timeline.addTween(cjs.Tween.get(this.instance_34).wait(205).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(109));
	this.timeline.addTween(cjs.Tween.get(this.instance_35).wait(206).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(108));
	this.timeline.addTween(cjs.Tween.get(this.instance_36).wait(207).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(107));
	this.timeline.addTween(cjs.Tween.get(this.instance_37).wait(208).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(106));
	this.timeline.addTween(cjs.Tween.get(this.instance_38).wait(209).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(105));
	this.timeline.addTween(cjs.Tween.get(this.instance_39).wait(210).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(104));
	this.timeline.addTween(cjs.Tween.get(this.instance_41).wait(212).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},8).wait(95));
	this.timeline.addTween(cjs.Tween.get(this.instance_43).wait(305).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9));
	this.timeline.addTween(cjs.Tween.get(this.instance_44).wait(306).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(8));
	this.timeline.addTween(cjs.Tween.get(this.instance_45).wait(307).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(7));
	this.timeline.addTween(cjs.Tween.get(this.instance_46).wait(308).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.instance_47).wait(309).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.instance_49).wait(311).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(3));
	this.timeline.addTween(cjs.Tween.get(this.instance_50).wait(313).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(9).to({_off:false},0).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();


// stage content:
(lib.SadMan_YaadIlani = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.___GetDepth___ = function(obj) {
		var depth = obj.depth;
		var cameraObj = this.___camera___instance;
		if(cameraObj && cameraObj.depth && obj.isAttachedToCamera)
		{
			depth += depth + cameraObj.depth;
		}
		return depth;
		}
	this.___needSorting___ = function() {
		for (var i = 0; i < this.getNumChildren() - 1; i++)
		{
			var prevDepth = this.___GetDepth___(this.getChildAt(i));
			var nextDepth = this.___GetDepth___(this.getChildAt(i + 1));
			if (prevDepth < nextDepth)
				return true;
		}
		return false;
	}
	this.___sortFunction___ = function(obj1, obj2) {
		return (this.exportRoot.___GetDepth___(obj2) - this.exportRoot.___GetDepth___(obj1));
	}
	this.on('tick', function (event){
		var curTimeline = event.currentTarget;
		if (curTimeline.___needSorting___()){
			this.sortChildren(curTimeline.___sortFunction___);
		}
	});

	// timeline functions:
	this.frame_374 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(374).call(this.frame_374).wait(1));

	// Car_And_Puddle_obj_
	this.Car_And_Puddle = new lib.Scene_1_Car_And_Puddle();
	this.Car_And_Puddle.name = "Car_And_Puddle";
	this.Car_And_Puddle.parent = this;
	this.Car_And_Puddle.setTransform(799.4,264.4,1,1,0,0,0,799.4,264.4);
	this.Car_And_Puddle.depth = 0;
	this.Car_And_Puddle.isAttachedToCamera = 0
	this.Car_And_Puddle.isAttachedToMask = 0
	this.Car_And_Puddle.layerDepth = 0
	this.Car_And_Puddle.layerIndex = 0
	this.Car_And_Puddle.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Car_And_Puddle).wait(276).to({_off:true},5).wait(94));

	// Banana_Skin_obj_
	this.Banana_Skin = new lib.Scene_1_Banana_Skin();
	this.Banana_Skin.name = "Banana_Skin";
	this.Banana_Skin.parent = this;
	this.Banana_Skin.setTransform(673.5,406.8,1,1,0,0,0,673.5,406.8);
	this.Banana_Skin.depth = 0;
	this.Banana_Skin.isAttachedToCamera = 0
	this.Banana_Skin.isAttachedToMask = 0
	this.Banana_Skin.layerDepth = 0
	this.Banana_Skin.layerIndex = 1
	this.Banana_Skin.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Banana_Skin).wait(180).to({_off:true},16).wait(179));

	// Setting_obj_
	this.Setting = new lib.Scene_1_Setting();
	this.Setting.name = "Setting";
	this.Setting.parent = this;
	this.Setting.setTransform(413.4,230.1,1,1,0,0,0,413.4,230.1);
	this.Setting.depth = 0;
	this.Setting.isAttachedToCamera = 0
	this.Setting.isAttachedToMask = 0
	this.Setting.layerDepth = 0
	this.Setting.layerIndex = 2
	this.Setting.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Setting).wait(244).to({_off:true},1).wait(130));

	// Tear_Drops_obj_
	this.Tear_Drops = new lib.Scene_1_Tear_Drops();
	this.Tear_Drops.name = "Tear_Drops";
	this.Tear_Drops.parent = this;
	this.Tear_Drops.depth = 0;
	this.Tear_Drops.isAttachedToCamera = 0
	this.Tear_Drops.isAttachedToMask = 0
	this.Tear_Drops.layerDepth = 0
	this.Tear_Drops.layerIndex = 3
	this.Tear_Drops.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Tear_Drops).wait(305).to({_off:true},19).wait(51));

	// Bent_Man_obj_
	this.Bent_Man = new lib.Scene_1_Bent_Man();
	this.Bent_Man.name = "Bent_Man";
	this.Bent_Man.parent = this;
	this.Bent_Man.depth = 0;
	this.Bent_Man.isAttachedToCamera = 0
	this.Bent_Man.isAttachedToMask = 0
	this.Bent_Man.layerDepth = 0
	this.Bent_Man.layerIndex = 4
	this.Bent_Man.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Bent_Man).wait(375));

	// Human_obj_
	this.Human = new lib.Scene_1_Human();
	this.Human.name = "Human";
	this.Human.parent = this;
	this.Human.setTransform(126.2,313.4,1,1,0,0,0,126.2,313.4);
	this.Human.depth = 0;
	this.Human.isAttachedToCamera = 0
	this.Human.isAttachedToMask = 0
	this.Human.layerDepth = 0
	this.Human.layerIndex = 5
	this.Human.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Human).wait(375));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(257.5,276.4,695.1,148.8);
// library properties:
lib.properties = {
	id: 'C5DB2A1D7CACF14E8D1C94630117C040',
	width: 640,
	height: 480,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/SadMan_YaadIlani_atlas_.png?1566475114987", id:"SadMan_YaadIlani_atlas_"},
		{src:"images/SadMan_YaadIlani_atlas_2.png?1566475114989", id:"SadMan_YaadIlani_atlas_2"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C5DB2A1D7CACF14E8D1C94630117C040'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


// Layer depth API : 

AdobeAn.Layer = new function() {
	this.getLayerZDepth = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth; else 0;";
		return eval(script);
	}
	this.setLayerZDepth = function(timeline, layerName, zDepth)
	{
		const MAX_zDepth = 10000;
		const MIN_zDepth = -5000;
		if(zDepth > MAX_zDepth)
			zDepth = MAX_zDepth;
		else if(zDepth < MIN_zDepth)
			zDepth = MIN_zDepth;
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth = " + zDepth + ";";
		eval(script);
	}
	this.removeLayer = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline.removeChild(timeline." + layerName + ");";
		eval(script);
	}
	this.addNewLayer = function(timeline, layerName, zDepth)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		zDepth = typeof zDepth !== 'undefined' ? zDepth : 0;
		var layer = new createjs.MovieClip();
		layer.name = layerName;
		layer.depth = zDepth;
		layer.layerIndex = 0;
		timeline.addChild(layer);
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;